# Capstone: Garage Sale Finder



USE npm start TO RUN BOTH SERVER AND CLIENT SIDE

### Wireframes




## Technologies Used

* JavaScript
* React
* HTML
* CSS
* MongoDB
* Typescript


## Getting Started

(link to deployed app)


## Next Steps

Future developments
