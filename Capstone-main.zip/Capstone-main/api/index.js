// index.js

const connectDB = require('./database'); // Adjust the path based on your project structure

// Run the connectDB function
connectDB();